// src/app/models/axe.model.ts
export interface Axe {
  axe_id: number;
  axe_libelle: string;
  deleted_at?: string; // optional
}
